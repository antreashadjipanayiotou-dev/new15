# Andreas Hadjipanayiotou Android App

Final Android project for GitHub Actions APK builds.

## Features
- 430x932-oriented modern mobile layout
- Home hero based on the supplied design
- Demos / Lyrics / Releases / Biography sections
- Admin button and PIN protection (default PIN: `1234`)
- Add MP3 demos directly from the phone with the Android file picker
- MP3 files are copied into the app's private storage
- Built-in MP3 player with play/pause and seek slider
- Add/delete lyrics and releases from the app
- Edit biography from the app
- FileProvider configured for opening local audio files
- GitHub Actions workflow in `.github/workflows/build-apk.yml`

## GitHub
Upload the project files themselves to the repository root. Do not upload the ZIP as the only repository content.

Then open **Actions → Build Android APK**. The generated debug APK is published as the `AndreasHadji-debug-apk` artifact.
